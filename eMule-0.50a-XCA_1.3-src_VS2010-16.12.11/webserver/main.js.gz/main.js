// main window
var ed2kinfo,iteminfo,toRefresh=0,toTip=0,colsort={},curwnd='',serverstate;
function noselect(e){var t=window.event.srcElement,name=t.tagName;return (name=="INPUT"&&t.type.toLowerCase()=="text")||name=="TEXTAREA";}
$(function(){
if($.browser.msie){document.onselectstart=noselect;document.ondragstart=noselect;}
//toolbar
$.each([{p:'kad',c:"LoadDlg($('#kaddlg'),'kad',1)"},{p:'server',c:"LoadWnd('server')"},{c:"LoadWnd('transfer')",p:"transfer"},{c:"LoadWnd('search')",p:"search"},{c:"LoadWnd('shared')",p:"shared"},{c:"LoadWnd('stats')",p:"stats"},{c:"LoadWnd('graphs')",p:"graphs"},{c:"LoadDlg($('#prefdlg'),'options',1)",p:"pref"},{c:"",p:"usermenu"}],function(i,n){$('#toolbar').append("<div class=\"t"+n.p+"\" onclick=\""+n.c+"\" title=\""+eval("lang."+n.p)+"\"></div>");});
$('.tusermenu').click(function(e){adminmenu();return showmenu(e);});
//append divs
$.each(['popMenu','popTip','overlay'],function(i,n){$('body').append("<div id=\""+n+"\"></div>");});
//append dlgs
$.each([{id:'loading',t:''},{id:'alertdlg',t:''},{id:'kaddlg',t:'KAD'},{id:'prefdlg',t:lang.pref},{id:'myinfo',t:lang.myinfo},{id:'log',t:lang.log},{id:'sinfo',t:lang.serverinfo},{id:'debuglog',t:lang.debuglog}],function(i,n){$('body').append('<div id="'+n.id+'" class="muledlg"><div class="titlebar"><div class="close">X</div>'+n.t+'</div><div class="dlgbody"></div></div>');})
$('#loading .dlgbody').append(lang.loading);
setDlg($('#loading'),1,0);
$('#alertdlg .dlgbody').append('<textarea class="autoHeight"></textarea>')
setDlg($('#alertdlg'),1,1);
setDlg($('#ed2k_open'),1,0);
//event
$('body').click(hideMenuTip).bind('contextmenu',function(){hideMenuTip();return false;});
$('#popTip').hover(clrtoTip,function(){toTip=setTimeout(_hideTip,500);});
$(window).resize(function(){resizeOverlay();listsresize();$('.muledlg:visible').each(function(i){resizeDlg($(this));});});
resizeOverlay();
setTimer();
});
function setTimer(){if(timeout>=1000)toRefresh=setTimeout(refresh,timeout);}
function clrTimer(){clearTimeout(toRefresh);toRefresh=0;}
function refresh(){if(toRefresh!=0){clrTimer();$.get('/?ses='+session+'&w=status&wnd='+curwnd,function(data){var jsonlen=data.indexOf('};')+2,end=jsonlen;eval('var s='+data.substring(0,end));if(curwnd=='transfer')$('#queuecount').text(s.queuecount);$.each(s.html,function(i,n){var d=data.substring(end,end=n+jsonlen);if(i=='statusbar')$("#"+i).html(d);else updList(i,d);});setTimer();});}}
function AutoWidthAll(jq){jq.find('.autoWidth').each(function(i){var neww=0;$(this).find('>div:eq(0)>:visible').each(function(){neww+=$(this).outerWidth();});$(this).width(neww);});}
function AutoWidth(sel){var neww=0;$(sel+' .headers>:visible').each(function(){neww+=$(this).outerWidth();});$(sel+' .headers').parent().width(neww);}
function listsresize(){var listh=$(window).height()-65,sel='#lists';if($(sel+'>.autoHeight').length==0){$(sel).height(listh);sel+='>div:visible';}$(sel).each(function(i){var jq=$(this).find('>.autoHeight:visible');if(jq.length>0){var newh=listh;$(this).height(listh).find('>:not(.autoHeight):visible').each(function(){newh-=$(this).outerHeight();});newh=newh/jq.length;jq.each(function(i){$(this).height(newh-$(this).outerHeight()+$(this).height())});}});}
// utilities
function Do(url,func){$.get('/?ses='+session+'&w='+url,func);}
function Open(url){window.open(url);}
function GoTo(url){location.href=url;}
function nop(){}
// menu and tip
function addMenu(ico,cmd,text){var line = '<div';if(ico!='gray'&&cmd!='')line+=' onclick="'+cmd+'"';line+='><div class="mico';if(ico!='')line+=' m'+ico;line+='"></div>'+text+'</div>';$('#popMenu').append(line);}
function addSep(){$('#popMenu').append('<div class="menusep"></div>');}
function columnmenu(menus,win,p){hideMenuTip();$(menus).find('>div').each(function(i){if(i>0&&$(this).text()!='') addMenu(($('.'+p+i).is('.hide'))?'':'checked',"$('."+p+i+"').toggleClass(\'hide\');Do('"+win+"&c=menu&list="+p+"&m="+i+"');AutoWidth('#"+p+"list')",$(this).text());})}
function move2Cursor(e,p){var x=e.pageX,y=e.pageY,sp=$(p),winw=parseInt($(window).width()),winh=parseInt($(window).height());if(x+sp.width()>winw&&x*2>winw)x-=sp.width();if(y+sp.height()>winh&&y*2>winh)y-=sp.height();return sp.css({left:x,top:y});}
function showmenu(e){if($('#popMenu').html()!=''){move2Cursor(e,'#popMenu').show().find('>div[onclick]').hover(function(){$(this).addClass('menuover');},function(){$(this).removeClass('menuover');});}return false;}
function hideMenuTip(){clrtoTip();$('#popMenu').hide().empty();_hideTip();}
function clrtoTip(){clearTimeout(toTip);}
function _hideTip(){$('#popTip').hide().empty();}
function showTip(e,code){hideMenuTip();move2Cursor(e,'#popTip').append(code);toTip=setTimeout(_showTip,500);}
function _showTip(){$('#popTip').show();toTip=setTimeout(_hideTip,2000);}
function downmenul(){
if(admin)addMenu('clrall',$('#downlist .item').length>0?"getlist('transfer&c=clearcompleted','down')":"",lang.clearcomplete);
addMenu('',"getlist('transfer','down')",lang.refresh);
}
function downmenu(n){
hideMenuTip();
var d=downinfo[n];
var url='transfer&file='+d.filehash+'&op=';
if(d.downstate == "hashing")
addMenu('herr','',lang.hashing);
else if(d.downstate == "error")
addMenu('herr','',lang.error);
else if(d.downstate == "completing")
addMenu('herr','',lang.completing);
else if(admin){
if(d.downstate == "complete"){
if (d.downloadable=="yes")
addMenu('fdown',"Open('/?ses="+session+"&w=getfile&filehash="+d.filehash+"')",lang.down);
}else{
if(d.downstate == "paused" || d.downstate == "stopped")addMenu('start',"getlist('"+url+"resume','down')",lang.resume);
else if(d.downstate != "stopped")addMenu('stop',"getlist('"+url+"stop','down')",lang.stop);
else if(d.downstate != "paused")addMenu('pause',"getlist('"+url+"pause','down')",lang.pause);
addMenu('cancel',"deldown('"+url+"','"+d.fname+"')",lang.cancel);
var ico='';
if(d.isgetflc == "enabled")ico='checked';
else if(d.isgetflc == "disabled")ico='getflc';
addMenu((ico==''?'getflc':ico),(ico==''?"":"getlist('"+url+"getflc','down')"),lang.flc);
}
downmenul();
addSep();
addMenu((d.priority=="Low")?'gray':'',"getlist('"+url+"priolow','down')",lang.low);
addMenu((d.priority=="Normal")?'gray':'',"getlist('"+url+"prionormal','down')",lang.normal);
addMenu((d.priority=="High")?'gray':'',"getlist('"+url+"priohigh','down')",lang.high);
addMenu((d.priority=="Auto")?'gray':'',"getlist('"+url+"prioauto','down')",lang.auto);
addSep();
if(cats.length>1){$.each(cats,function(i,n){addMenu((i==d.catindex?'gray':''),"getlist('"+url+"setcat&filecat="+i+"','down')",n);});addSep();}
}
if (d.fcomments=="yes")addMenu('comment',"LoadClassDlg('commentlist&filehash="+d.filehash+"')",lang.comment);
ed2kinfo = d.ed2k;
iteminfo = d.finfo;
addMenu('info','ShowLink(iteminfo)',lang.info);
addMenu('ed2k','ShowLink(ed2kinfo)',lang.link);
}
function deldown(url,name){hideMenuTip();if(confirm(lang.confirmdelete+name))getlist(url+'cancel','down');}
function servermenul(){
var cmd,text;
if(serverstate=='disconnected'){cmd='connect';text=lang.connectany;}else{cmd='disconnect';text=lang.disconnect;}
addMenu('conn',$('#serverlist .item').length>0?"servercmd('server&c='+cmd)":"",text);
addMenu('',"getlist('server','server')",lang.refresh);
}
function servermenu(n){
hideMenuTip();
var s=serverinfo[n];
if(admin){
var url='server&ip='+s.ip+'&port='+s.port+'&c=';
addMenu('conn',"Do('"+url+"connect',refresh)",lang.connect);
addMenu('cancel',"delsvr('"+url+"')",lang.removeserver);
if(s.isstatic)addMenu('checked',"getlist('"+url+"removefromstatic','server')",lang.static);
else addMenu('stat',"getlist('"+url+"addtostatic','server')",lang.static);
servermenul();
addSep();
addMenu((s.priority=="Low")?'gray':'',"getlist('"+url+"priolow','server')",lang.low);
addMenu((s.priority=="Normal")?'gray':'',"getlist('"+url+"prionormal','server')",lang.normal);
addMenu((s.priority=="High")?'gray':'',"getlist('"+url+"priohigh','server')",lang.high);
addSep();
}
ed2kinfo = s.ed2k;
addMenu('ed2k','ShowLink(ed2kinfo)',lang.link);
}
function delsvr(url){hideMenuTip();if(confirm(lang.confirmremove))getlist(url+'remove','server')}
function sharedmenu(n)
{
hideMenuTip();
var s=sharedinfo[n];
if (s.downloadable=="yes"){addMenu('fdown',"Open('/?ses="+session+"'&w=getfile&filehash="+s.hash +"')",lang.down);addSep();}
if(admin){
var url='shared&hash='+s.hash+'&prio=';
addMenu((s.priority=="VeryLow")?'gray':'',"getlist('"+url+"verylow','shared')",lang.verylow);
addMenu((s.priority=="Low")?'gray':'',"getlist('"+url+"low','shared')",lang.low);
addMenu((s.priority=="Normal")?'gray':'',"getlist('"+url+"normal','shared')",lang.normal);
addMenu((s.priority=="High")?'gray':'',"getlist('"+url+"high','shared')",lang.high);
addMenu((s.priority=="Release")?'gray':'',"getlist('"+url+"release','shared')",lang.release);
addMenu((s.priority=="PowerRelease")?'gray':'',"getlist('"+url+"PowerRelease','shared')",lang.powerrelease);
addMenu((s.priority=="Auto")?'gray':'',"getlist('"+url+"auto','shared')",lang.auto);
addSep();
}
ed2kinfo = s.ed2k;
addMenu('ed2k','ShowLink(ed2kinfo)',lang.link);
}
function adminmenu(){
hideMenuTip();
if(admin){addMenu('ed2k',"show($('#ed2k_open'))",lang.link);addSep();}
addMenu('info',"LoadDlg($('#myinfo'),'myinfo',1)",lang.myinfo);
addMenu('log',"LoadDlg($('#log'),'log',1)",lang.log);
addMenu('log',"LoadDlg($('#sinfo'),'sinfo',1)",lang.serverinfo);
addMenu('log',"LoadDlg($('#debuglog'),'debuglog',1)",lang.debuglog);
addSep();
addMenu('ver',"Open(verchecklink)",lang.vercheck);
addMenu('home',"Open('http://emule-project.net')",lang.home);
addMenu('forum',"Open('http://forum.emule-project.net')",lang.forum);
addMenu('info',"Open('http://www.emule-project.net/home/perl/help.cgi')",lang.help);
addSep();
addMenu('logout',"LoadWnd('logout')",lang.logout);
if(hilevel){
addMenu('close',"syscmd('close')",lang.close);
addMenu('shutdown',"syscmd('shutdown')",lang.shutdown);
addMenu('reboot',"syscmd('reboot')",lang.reboot);
}
}
function syscmd(cmd){hideMenuTip();if(confirm(eval('lang.confirm'+cmd)))LoadWnd(cmd);}
function filtermenu(c){
hideMenuTip();
if(c==catindex){
addMenu((curfilter==0?'gray':''),"getlist('transfer&cat="+c+"','down');curfilter=0",cats[c]);
addSep();
$.each(filter,function(i,n){addMenu((-1==curfilter+i?'gray':''),"getlist('transfer&cat="+(-i-1)+"','down');curfilter="+(-i-1),n);});
addSep();
}
if(admin){
var url='transfer&c=menuprio&p=';
addMenu('',"Do('"+url+"low')",lang.low);
addMenu('',"Do('"+url+"normal')",lang.normal);
addMenu('',"Do('"+url+"high')",lang.high);
addMenu('',"Do('"+url+"auto')",lang.auto);
}
}
function upmenu(n){
hideMenuTip();
if(admin){
var u=upinfo[n];
if(u.clientextra == "friend")
addMenu('checked',"getlist('transfer&op=removefriend&userhash="+u.userhash+"','up')",lang.friend);
else
addMenu('friend',"getlist('transfer&op=addfriend&userhash="+u.userhash+"','up')",lang.friend);
}
}
function searchmenu(n){
hideMenuTip();
var s=searchinfo[n];
ed2kinfo = s.ed2k;
addMenu('ed2k','ShowLink(ed2kinfo)',lang.link);
}
// dialog
function showOverlay(){$("#overlay").css({opacity:0}).show().animate({opacity:.3});}
function hideOverlay(){$("#overlay").animate({opacity:0},{complete:function(){$("#overlay").hide();}});}
function resizeOverlay(){$("#overlay").width($(window).width()).height($(window).height());}
function setDlg(jq,keep,mod){jq.css({opacity:0}).show();resizeDlg(jq);jq.hide().css({opacity:1});jq.draggable({containment:'body',handle:'.titlebar',helper: function(event) {return $('<div id="helper" style="width:'+$(this).width()+'px;height:'+$(this).height()+'px;z-index:10000;border:2px solid #AAA;"></div>');},stop:function(){$(this).css({left:$('#helper').css('left'),top:$('#helper').css('top')});},stack:{group:'.muledlg',min:1001}}).find('.close').click(keep?(mod?function(){jq.fadeOut();hideOverlay();}:function(){jq.fadeOut();}):function(){jq.fadeOut(300,function(){jq.remove();});});}
function centerDlg(jq){jq.css({left:($(window).width()-jq.width())/2,top:($(window).height()-jq.outerHeight())/2});}
function resizeDlg(jq){var dlgbody=jq.find('.dlgbody'),realh=dlgbody.outerHeight()+jq.find('.titlebar').outerHeight();if(realh){var maxheight=$(window).height()*.75,ahs=dlgbody.find('.autoHeight'),bodyh=dlgbody.height();if(realh<maxheight){if(realh<jq.height())bodyh+=jq.height()-realh;}else if(ahs.length>0){jq.height(maxheight);bodyh+=maxheight-realh;dlgbody.height(bodyh);}ahs.each(function(i){$(this).parent().height(bodyh);var newh=bodyh;$(this).siblings().each(function(){newh-=$(this).outerHeight();});$(this).height(newh);});}centerDlg(jq);}
function fillDlg(jq,data){jq.find('.dlgbody').html(data);setDlg(jq,1,1);}
function show(jq){resizeDlg(jq);jq.fadeIn();}
function showModal(jq){showOverlay();show(jq);}
function showModeless(data,keep){$('body').append(data);var jq=$('body>div:last');setDlg(jq,keep,0);jq.fadeIn();}
function LoadClassDlg(url){Do(url,function(data){showModeless(data,0);});}
function LoadDlg(jq,url,mod){centerDlg($('#loading').show());Do(url,function(data){$('#loading').fadeOut();fillDlg(jq,data);if(mod)showOverlay();jq.fadeIn();});}
function LoadWnd(url){centerDlg($('#loading').show());$("#lists").load('/?ses='+session+'&w='+url,function(){curwnd=url;$('#loading').fadeOut();listsresize();AutoWidthAll($("#lists"));});}
function ShowLink(data){$('#alertdlg textarea').val(data);showModal($('#alertdlg'));}
// lists
function InitColumnHeader(w,p,c,h){eval("colsort."+p+"={c:"+c+",r:0};");$('#'+p+'list .headers').bind('contextmenu',function(e){columnmenu(this,w,p);return showmenu(e);});$.each(h,function(i,n){$('.'+p+n).addClass('hide');});}
function updList(p,data){eval("if(typeof "+p+"info!='undefined')"+p+"info=[];");var sel='#'+p+'list';$(sel+' .headers img').remove();$(sel+'>.item').remove();$(sel).append(data).find('>div').each(function(i){if($(this).is('.hide')){$('.'+p+i).addClass('hide');}});}
function getlist(win,p,sort,dbl){var url='/?ses='+session+'&w='+win+'&l=sort&list='+p;if(sort!=undefined){var col=eval("colsort."+p+".c"),rev=eval("colsort."+p+".r"),d=dbl!=undefined,nrev;var ncol=(d&&((!rev&&col==(sort+1))||(rev&&col==sort)))?sort+1:sort;eval("colsort."+p+".c="+ncol+";");url+='&sort='+ncol;if(col==sort||(d&&col==(sort+1)))url+='&sortAsc='+(rev?0:1);}$.get(url,function(data){updList(p,data);});}
function SortServers(sort){getlist('server','server',sort);}
function SortDowns(sort){getlist('transfer','down',sort);}
function SortUps(sort){getlist('transfer','up',sort);}
function SortQueues(sort){getlist('transfer','queue',sort);}
function SortSearches(sort){getlist('search','search',sort);}
function SortShareds(sort,dbl){getlist('shared','shared',sort,dbl);}
function Togglelist(p){var plist=$('#'+p+'list').parent();if(plist.is(".autoHeight")){Do('transfer&show'+p+'=false',function(){plist.addClass('hide').removeClass("autoHeight");listsresize();});}else{getlist('transfer&show'+p+'=true',p);}}
function showList(p){$('#'+p+'list').parent().removeClass("hide").addClass("autoHeight");AutoWidth('#'+p+'list');listsresize();}
function onUpdate(p,rvs){
eval("colsort."+p+".r="+rvs+";");
var col=eval("colsort."+p+".c"),sel='#'+p+'list .headers .col-',dbl;
sel+=(dbl=($(sel+col).length==0))?(col-1):col;
if($(sel+">div").length>1)sel+=">div:last";
$(sel).append('<img src="l_'+(dbl?(rvs?'updouble':'dndouble'):(rvs?'up':'down'))+'arrow.gif">');
if(p!='queue')$('#'+p+'list .item').each(function(i){
$(this).click(function(){$('#'+p+'list .clicked').removeClass('clicked');$(this).addClass('clicked');})
.bind('contextmenu',function(e){$(this).click();eval(p+'menu('+i+')');return showmenu(e);});
if(p=='down')$(this).find('.down0').hover(function(e){showTip(e,downinfo[i].finfo);},clrtoTip);
else if(p=='up')$(this).find('.up0').hover(function(e){showTip(e,upinfo[i].finfo);},nop);
else if(p=='search')$(this).dblclick(function(){$(this).find('input[name="downit"]').attr('checked',1);});	
else if(p=='server')$(this).dblclick(function(){if(serverstate=='disconnected'){var s=serverinfo[i];Do('server&ip='+s.ip+'&port='+s.port+'&c=connect',refresh);}});	
});
}
//wnds
function initServer(c1,h1){InitColumnHeader('server','server',c1,h1);if(admin)$('#serverlist').parent().bind('contextmenu',function(e){hideMenuTip();servermenul();return showmenu(e);});}
function initTransfer(c1,h1,c2,h2,c3,h3){InitColumnHeader('transfer','down',c1,h1);InitColumnHeader('transfer','up',c2,h2);InitColumnHeader('transfer','queue',c3,h3);$.each(cats,function(i,n){$('#downCatFilter').append("<div onclick=\"if(catindex!="+i+"){getlist('transfer&cat="+i+"','down');curfilter=0;}\">"+n+"</div>");});$('#downCatFilter>div').each(function(i){$(this).bind('contextmenu',function(e){filtermenu(i);return showmenu(e);});});$('#downlist').parent().bind('contextmenu',function(e){hideMenuTip();downmenul();return showmenu(e);});}
function initSearch(c1,h1){$('#searchleft').hover(function(){$('#searchleft').css({left:0});$('#searchright').css({marginLeft:330});},function(){$('#searchleft').css({left:-326});$('#searchright').css({marginLeft:4});});InitColumnHeader('search','search',c1,h1);$('#searchtab>div').each(function(i){if(i<2){$(this).click(function(){$('#searchtab .selectedtab').removeClass('selectedtab');$('#searchleft form').hide().eq(i).show();$(this).addClass('selectedtab');});}});}
// cmd
function clearlog(log){Do(log+'&clear=yes',function(){$('#'+log+' .close').click();});}
function startDown(){if($('#ed2k_ed2k').val()!=''){var url='transfer&ed2k='+$('#ed2k_ed2k').val();if($('select[name="cat"]').length==1)url+='&cat='+$('select[name="cat"] option:selected').val();if(curwnd='transfer')getlist(url,'down');else Do(url);}}
// server
function updateservermet(){if($('#usm_servermeturl').val()!='')getlist('server&c=updateservermetfromurl&servermeturl='+$('#usm_servermeturl').val(),'server');}
function addserver(){if($('#as_serveraddr').val()!=''&&$('#as_serverport').val()!='')getlist('server&c=addserver&'+$.param({serveraddr:$('#as_serveraddr').val(),serverport:$('#as_serverport').val(),servername:$('#as_servername').val(),addtostatic:$('#as_addtostatic').attr('checked'),connectnow:$('#as_connectnow').attr('checked'),priority:$('#as_priority option:selected').val()}),'server');}
// search
function search(){if($('#s_tosearch').val()!='')getlist('search&'+$.param({tosearch:$('#s_tosearch').val(),type:$('#s_type option:selected').val(),min:$('#s_min').val(),max:$('#s_max').val(),avail:$('#s_avail').val(),ext:$('#s_ext').val(),method:$('input[name="s_method"]:checked').val()}),'search');}
function fdsearch(){if($('#fd_pattern').val()!='')Open('http://www.filedonkey.com/search.html?'+$.param({pattern:$('#fd_pattern').val(),scope:$('#fd_scope option:selected').val(),min_size:$('#fd_min_size').val(),max:$('#fd_max_size').val()}));}
function downsearch(){if($('input[name="downit"]:checked').length>0){var url='search';if($('select[name="cat"]').length==1)url+='&cat='+$('select[name="cat"] option:selected').val();url+='&downloads=';$('input[name="downit"]:checked').each(function(i){if(i>0)url+='|';url+=$(this).parents('.item').find('>.search2').text();});Do(url);}}
function toggle(t){$(t).next(':eq(0)').toggle();$(t).find('.sico:eq(0)').toggleClass('stp');}
function addDiv(jq,w,h){if(w!=0)jq.append("<div style='width:"+w+"px;margin-top:"+(140-h)+"px;height:"+h+"px;'></div>");}
function traceGraph(jq,speed,MaxSpeed){if(MaxSpeed==0) MaxSpeed=1;var h,lasth=0,width=500-speed.length;for(i=0;i<speed.length;i++){h=(speed[i]>MaxSpeed)?140:Math.round(speed[i]*140/MaxSpeed);if(lasth!=h){addDiv(jq,width,lasth);width=1;lasth=h;}else ++width;}addDiv(jq,width,h);}
function savePref(){$.get('/',{ses:session,w:'options',saveprefs:'true',gzip:$('#pref_gzip').attr('checked'),refresh:$('#pref_refresh').val(),maxcapdown:$('#pref_maxcapdown').val(),maxcapup:$('#pref_maxcapup').val(),maxdown:$('#pref_maxdown').val(),maxup:$('#pref_maxup').val(),maxsources:$('#pref_maxsources').val(),maxconnections:$('#pref_maxconnections').val(),maxconnectionsperfive:$('#pref_maxconnectionsperfive').val()},function(){timeout=parseInt($('#pref_refresh').val())*1000;clrTimer();setTimer();});}
function bootstrap(){if($('#kad_ip').val()!=''&&$('#kad_port').val()!='')$.get('/',{ses:session,w:'kad',c:'bootstrap',ip:$('#kad_ip').val(),port:$('#kad_port').val()});}
function kadcmd(cmd){if($('#kaddlg').css('display')!='none')$('#kaddlg .close').click();Do('kad&c='+cmd);refresh();}
function servercmd(cmd){Do('server&c='+cmd,refresh);}
